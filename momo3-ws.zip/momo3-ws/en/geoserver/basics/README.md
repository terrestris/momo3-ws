# GeoServer Basics

GeoServer is an open, Java-based server that enables publishing and editing of
spatial data based on the standards of the Open Geospatial Consortium (OGC) (here
esp. WMS and WFS). A particular strength of GeoServer is the flexibility by
which it can be expanded to include additional functionality.
