{
    region: 'north',
    collapsible: false,
    height: 60,
    border: false,
    bodyPadding: 5,
    items: [{
        xtype: 'image',
        src: './materials/ext-logo.png',
        height: 50
    }]
}
