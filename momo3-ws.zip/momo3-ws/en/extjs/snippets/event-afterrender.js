afterrender: function(cmp) {
    Ext.toast({
        html: 'Click <code>Load data</code>!',
        title: 'Hint',
        align: 't',
    });
}
