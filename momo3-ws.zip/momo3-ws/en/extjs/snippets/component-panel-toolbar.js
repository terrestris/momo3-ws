tbar: [{
    xtype: 'button',
    text: 'Button 1',
    iconCls: 'fa fa-repeat'
}]
