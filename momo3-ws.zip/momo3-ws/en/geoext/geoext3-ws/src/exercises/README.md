# The exercise-folder

Please store all your exercises inside this folder.

If you e.g. store a file named `map.html` inside this directory, and you are serving the workshop as recommended, than this file can be accessed via the following URL:

http://localhost:4000/exercises/map.html
